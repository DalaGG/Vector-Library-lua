

--[[
Vector.save_vector(vec)
This function takes a vector vec as input, gets its size using the Vector.get_size function, 
creates a table vec_table containing the axes, size, and data of the vector, 
and saves the vector table as a comma-separated string to a text file "Vector_Var.txt".
]]

function Vector.save_vector(vec)
    local axes, size = Vector.get_size(vec)
    local vec_table = {}
    vec_table.axes = axes
    vec_table.size = size
    vec_table.data = vec

    local file = io.open("Vector_Var.txt", "a")
    file:write(table.concat(vec_table, ",") .. "\n")
    file:close()
end
