
--[[
This function takes four parameters:

inputs: a vector containing the input values
weights: a matrix containing the weights of the neural network
biases: a vector containing the bias values of the neural network
activation_func: a function representing the activation function to be applied to the weighted sum
The function calculates the weighted sum of the inputs by taking the dot product of the input vector and the weight matrix. It then adds the bias vector to the weighted sum and applies the activation function to the resulting vector. The resulting vector is returned as the output of the forward propagation.

Note that the activation_func parameter should be a function that takes a scalar as input and returns a scalar. Common activation functions used in neural networks include sigmoid, ReLU, and tanh.
]]

local Vector = require("int")

function Vector.forwardprop_vectors(inputs, weights, biases, activation_func)
    -- Calculate the weighted sum of inputs
    local weighted_sum = Vector.dot(inputs, weights)
    
    -- Add the bias vector to the weighted sum
    local z = Vector.add(weighted_sum, biases)
    
    -- Apply the activation function to z
    local a = Vector.map(z, activation_func)
    
    return a
end
