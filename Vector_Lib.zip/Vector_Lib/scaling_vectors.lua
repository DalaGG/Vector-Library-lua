
--[[
Vector.scaling_vectors(scalar, vector_name)
    Scale a vector by multiplying each component by a scalar value.

    Parameters:
        - scalar: A numeric value to scale the vector.
        - vector_name: A string representing the name of the vector to scale.

    Returns:
        - A table representing the scaled vector if successful, nil otherwise.

To use this function, you can call it with a scalar value and the name of the vector you want to scale:
-- Scale the "my_vector" vector by 2
local scaled_vector = Vector.scaling_vectors(2, "my_vector")
This will load the "my_vector" vector from file, scale it by multiplying each component by 2, and save the scaled vector back to file. The function will return the scaled vector if successful.

]]

-- Load the Vector library
local Vector = require("Vector")

-- Define the scaling_vectors function
function Vector.scaling_vectors(scalar, vector_name)
    -- Load the vector from file
    local vector = Vector.get_vector(vector_name)

    -- Check that the vector was loaded successfully
    if not vector then
        print("Error: Vector not found")
        return
    end

    -- Scale the vector
    for i = 1, #vector do
        vector[i] = vector[i] * scalar
    end

    -- Save the scaled vector to file
    Vector.save_vector(vector_name, vector)

    -- Return the scaled vector
    return vector
end
