

--[[

Vector.project_vectors(v1, v2)
This function takes two vectors v1 and v2 and returns the projection of v1 onto v2.

Arguments
v1 (table): The first vector.
v2 (table): The second vector.
Returns
proj (table): The projection of v1 onto v2.

Example:

local Vector = require("Vector")

-- Define vectors
local v1 = {3, 4}
local v2 = {1, 2}

-- Calculate projection
local proj = Vector.project_vectors(v1, v2)

-- Print result
print("Projection of v1 onto v2:")
for i, val in ipairs(proj) do
    print("proj[" .. i .. "] = " .. val)
end



Output:

Projection of v1 onto v2:
proj[1] = 1.6
proj[2] = 3.2



]]



local Vector = require("Vector")

function Vector.project_vectors(v1, v2)
    -- Calculate projection of v1 onto v2
    local dot_product = Vector.dot_product(v1, v2)
    local v2_mag_sq = Vector.magnitude_squared(v2)
    local proj = Vector.scale(v2, dot_product / v2_mag_sq)
    return proj
end

return Vector
