
--[[
Function: sub_vectors(vector_names)
Description:

This function takes a list of vector names as input and subtracts them element-wise to create a new vector. The input vector names should match the table keys used in the Vector_Var.txt file. The resulting difference vector will be saved to a file with a name based on the input vector names and returned as a Lua table.

Parameters:

vector_names (table): A table of strings representing the names of the vectors to subtract. The names should match the table keys used in the Vector_Var.txt file.
Returns:

diff (table): A Lua table representing the difference vector of the input vectors.
Example Usage:

-- Subtract vectors "vector1" and "vector2"
v1 = sub_vectors({"vector1", "vector2"})

-- Subtract vectors "a", "b", and "c"
v2 = sub_vectors({"a", "b", "c"})


Notes:

The input vector names should match the table keys used in the Vector_Var.txt file, otherwise an error will be returned.
The resulting difference vector will be saved to a file with a name based on the input vector names, with the format <vector_name_1>_<vector_name_2>_..._<vector_name_n>_diff.txt. The file will be saved in the same directory as the script that calls this function.
The function assumes that the vector values are stored as comma-separated values in the Vector_Var.txt file, with no additional whitespace or formatting.
The function also assumes that all input vectors have the same size, otherwise an error will be returned.

]]


function Vector.sub_vectors(vector_names)
  local vectors = {}
  for _, name in ipairs(vector_names) do
    local vector = io.open("Vector_Var.txt", "r")
    local value = vector:read("*all")
    vector:close()
    vectors[name] = {}
    for num in value:gmatch("%-?%d+") do
      table.insert(vectors[name], tonumber(num))
    end
  end

  local size = #vectors[vector_names[1]]
  for i = 2, #vector_names do
    if #vectors[vector_names[i]] ~= size then
      error("Vectors must be the same size")
    end
  end

  local result = {}
  for i = 1, size do
    local sum = vectors[vector_names[1]][i]
    for j = 2, #vector_names do
      sum = sum - vectors[vector_names[j]][i]
    end
    table.insert(result, sum)
  end

  local file_name = table.concat(vector_names, "_") .. "_diff.txt"
  local file = io.open(file_name, "w")
  file:write(table.concat(result, ", "))
  file:close()

  return result
end
