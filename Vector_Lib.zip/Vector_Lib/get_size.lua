

--[[
Vector.get_size(vec)
This function takes a vector vec as input and returns its number of axes and size. 
It checks the type of the first element of the vector to determine if it is a scalar or a multi-dimensional array. 
If it is a multi-dimensional array, it returns the number of axes as the length of the first element, and the size as the length of the vector. 
Otherwise, it returns the number of axes as 1 and the size as the length of the vector.
]]

function Vector.get_size(vec)
    local size = #vec
    local axes = 1
    if type(vec[1]) == "table" then
        axes = #vec[1]
    end
    return axes, size
end
