
--[[

Functions:
- check_boolean (function): Checks if a given value is a boolean.
- create_vector (function): Creates a new vector with the given values.
- get_size (function): Returns the size of a given vector.
- save_vector (function): Saves a given vector to a file.
- add_vectors (function): Adds two vectors together.
- sub_vectors (function): Subtracts one vector from another.
- scaling_vectors (function): Scales a vector by a given scalar.
- rotate_vector (function): Rotates a given vector by a given angle.
- norm_vectors (function): Computes the Euclidean norm of a given vector.
- project_vectors (function): Projects a given vector onto another vector.
- dimreduct_vectors (function): Performs dimensionality reduction on a given set of vectors.
- forwardprop_vectors (function): Performs forward propagation on a given set of input vectors through a neural network.
- activation_func (function): Computes the output of the activation function for a given input.
- backpropagate (function): Performs backpropagation through a neural network to calculate the error gradient.


]]



local Vector = {}

-- Load Vector library functions
Vector.check_boolean = require("check_boolean")
Vector.create_vector = require("create_vector")
Vector.get_size = require("get_size")
Vector.save_vector = require("save_vector")
Vector.add_vectors = require("add_vectors")
Vector.sub_vectors = require("sub_vectors")
Vector.scaling_vectors = require("scaling_vectors")
Vector.rotate_vector = require("rotate_vectors")
Vector.norm_vectors = require("norm_vectors")
Vector.project_vectors = require("project_vectors")
Vector.dimreduct_vectors = require("dimreduct_vectors")
Vector.forwardprop_vectors = require("forwardprop_vectors")
Vector.activation_func = require("activation_func")
Vector.backpropagate = require("backpropagate")

-- Use Vector functions here

return Vector



--[[
PLEASE READ THIS DOCUMENTATION FIRST! :) 

Int.lua - A Lua library for managing integer vectors

Functions:
Vector.check_boolean(boolean_string, vector) - Check if the boolean in the boolean string is true for the given vector
- Parameters:
- boolean_string (string): A string containing a boolean value ("true" or "false")
- vector (table): A table containing integer values
- Returns:
- If the boolean is false, returns an error message
- If the boolean is true and the vector has a value, returns the vector
- If the boolean is true and the vector is nil, returns an error message

Vector.create_vector(vector_values) - Create a vector from a list of values
- Parameters:
- vector_values (table): A table containing integer values
- Returns:
- A table representing the vector

Vector.get_size(vector) - Get the size of the vector
- Parameters:
- vector (table): A table representing a vector
- Returns:
- The number of elements in the vector

Vector.save_vector(vector) - Save a vector to a file
- Parameters:
- vector (table): A table representing a vector
- Returns:
- None
- Side effects:
- The vector is saved to the file "Vector_Var.txt". If the file does not exist, it will be created. The vector is appended to the end of the file as a table.

Vector.add_vectors() - Add multiple vectors stored in Vector_Var.txt and return the result as a vector
- Parameters:
- None
- Returns:
- A table representing the resulting vector after adding all the vectors stored in Vector_Var.txt

Vector.sub_vectors() - Subtract multiple vectors stored in Vector_Var.txt and return the result as a vector
- Parameters:
- None
- Returns:
- A table representing the resulting vector after subtracting all the vectors stored in Vector_Var.txt

Vector.scaling_vectors(scaling_factor) - Scale a vector stored in Vector_Var.txt by a given scaling factor
- Parameters:
- scaling_factor (number): A number representing the scaling factor
- Returns:
- A table representing the resulting scaled vector after multiplying each element in the vector by the scaling factor

Vector.rotate_vector(rotation_angle) - Rotate a vector stored in Vector_Var.txt by a given angle
- Parameters:
- rotation_angle (number): A number representing the angle to rotate the vector by
- Returns:
- A table representing the resulting rotated vector after applying the rotation matrix to the original vector

Vector.norm_vectors() - Normalize a vector stored in Vector_Var.txt
- Parameters:
- None
- Returns:
- A table representing the resulting normalized vector after dividing each element in the vector by the magnitude of the vector

Vector.project_vectors(target_vector) - Project a vector stored in Vector_Var.txt onto a target vector
- Parameters:
- target_vector (table): A table representing the target vector to project onto
- Returns:
- A table representing the resulting projected vector after applying the projection formula to the original vector and the target vector

Vector.dimreduct_vectors(target_dimension) - Reduce the dimensionality of a vector stored in Vector_Var.txt to a given dimension
- Parameters:
- target_dimension (number): A number representing the target dimension
- Returns:
- A table representing the resulting vector after projecting the original vector onto a subspace of the target dimension

Vector.forwardprop_vectors() - Perform forward propagation on a neural network to obtain the output for a given input vector

Parameters:
neural_network (table): A table representing the neural network
input_vector (table): A table representing the input vector to the neural network
Returns:
A table representing the output vector obtained from the forward propagation
Vector.activation_func() - Apply an activation function to the output of a neural network layer

Parameters:
activation_function (string): A string representing the name of the activation function to apply
input_vector (table): A table representing the input vector to the activation function
Returns:
A table representing the output vector obtained after applying the activation function to the input vector
Vector.backpropagate() - Perform backpropagation on a neural network to obtain the gradients of the loss function with respect to the weights and biases of the network

Parameters:
neural_network (table): A table representing the neural network
input_vector (table): A table representing the input vector to the neural network
target_vector (table): A table representing the target output vector for the given input vector
Returns:
A table representing the gradients of the loss function with respect to the weights and biases of the network, obtained from the backpropagation algorithm


]]