
--[[

Here's an example of how you can use this sigmoid function within the Vector Library:

-- load the Vector Library and the sigmoid function
local Vector = require("Vector")
local sigmoid = require("sigmoid")

-- create a vector
local v = Vector.create_vector({1, 2, 3})

-- apply the sigmoid function to the vector
local sigmoid_v = sigmoid(v)

-- print the result
Vector.print_vector(sigmoid_v) -- prints {0.7310585786300049, 0.8807970779778823, 0.9525741268224334}

In this example, we first load the Vector Library and the sigmoid function. We then create a vector v using the create_vector function from the Vector Library. 
We apply the sigmoid function to this vector, which returns a new vector with the sigmoid function applied to each element. 
Finally, we print the resulting vector using the print_vector function from the Vector Library.

]]


local function Vecotr.sigmoid(vector)
    local result = {}
    for i, v in ipairs(vector) do
        result[i] = 1 / (1 + math.exp(-v))
    end
    return result
end

return sigmoid
