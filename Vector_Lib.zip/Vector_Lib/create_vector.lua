

--[[
Vector.create_vector(...)
This function takes any number of arguments as input and returns them as a vector. 
It checks the type of the first argument to determine if it is a scalar or a multi-dimensional array. 
If it is a scalar, it creates a vector with one element. 
If it is a multi-dimensional array, it creates a vector with the same dimensions as the array.
]]

function Vector.create_vector(...)
    local args = {...}
    local vec = {}
    if type(args[1]) == "table" then
        vec = args[1]
    else
        vec = args
    end
    return vec
end
