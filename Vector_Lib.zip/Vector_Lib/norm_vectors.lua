
--[[
The norm_vectors function first checks if the vector exists using the create_vector function, and throws an error if it doesn't exist. It then gets the size of the vector using the get_size function.

Next, it computes the magnitude of the vector using the formula sqrt(x1^2 + x2^2 + ... + xn^2), where x1, x2, ..., xn are the components of the vector. Once the magnitude is computed, the vector is normalized by dividing each component by the magnitude.

Finally, the normalized vector is returned.

To use this function, you can simply call it with a string representing the vector you want to normalize:

local Vector = require("Vector")

-- Create a new vector
Vector.save_vector("my_vector", {1, 2, 3})

-- Normalize the vector
local normalized_vec = Vector.norm_vectors("my_vector")

The normalized_vec variable will contain the normalized vector.


]]



local Vector = {}

-- Load necessary functions
Vector.check_boolean = require("check_boolean")
Vector.create_vector = require("create_vector")
Vector.get_size = require("get_size")
Vector.save_vector = require("save_vector")

-- Function to normalize a given vector
function Vector.norm_vectors(vec_string)
  -- Check if vector exists
  local vec = Vector.create_vector(vec_string)
  if not vec then
    error("Vector does not exist")
  end
  
  -- Get vector size
  local vec_size = Vector.get_size(vec)
  
  -- Compute magnitude of vector
  local magnitude = 0
  for i = 1, vec_size do
    magnitude = magnitude + vec[i]^2
  end
  magnitude = math.sqrt(magnitude)
  
  -- Normalize the vector
  local normalized_vec = {}
  for i = 1, vec_size do
    normalized_vec[i] = vec[i] / magnitude
  end
  
  -- Return the normalized vector
  return normalized_vec
end

-- Return the Vector module
return Vector
