
--[[

Function: add_vectors(vector_names)
Description:

This function takes a list of vector names as input and adds them element-wise to create a new vector. The input vector names should match the table keys used in the Vector_Var.txt file. The resulting sum vector will be saved to a file with a name based on the input vector names and returned as a Lua table.

Parameters:

vector_names (table): A table of strings representing the names of the vectors to add. The names should match the table keys used in the Vector_Var.txt file.
Returns:

sum (table): A Lua table representing the sum vector of the input vectors.
Example Usage:

-- Add vectors "vector1" and "vector2"
v1 = add_vectors({"vector1", "vector2"})

-- Add vectors "a", "b", and "c"
v2 = add_vectors({"a", "b", "c"})

Notes:

The input vector names should match the table keys used in the Vector_Var.txt file, otherwise an error will be returned.
The resulting sum vector will be saved to a file with a name based on the input vector names, with the format <vector_name_1>_<vector_name_2>_..._<vector_name_n>_sum.txt. The file will be saved in the same directory as the script that calls this function.
The function assumes that the vector values are stored as comma-separated values in the Vector_Var.txt file, with no additional whitespace or formatting.

]]

function Vector.add_vectors(vector_names)
  local vectors = {}
  
  -- Load each vector from file
  for i, name in ipairs(vector_names) do
    local filename = name .. ".txt"
    local file = io.open(filename, "r")
    if file then
      local str = file:read("*all")
      local vector = load("return " .. str)()
      table.insert(vectors, vector)
      file:close()
    else
      print("Error: Could not find file " .. filename)
    end
  end
  
  -- Check that all vectors have the same size
  local size = #vectors[1]
  for i, v in ipairs(vectors) do
    if #v ~= size then
      print("Error: Vectors have different sizes")
      return
    end
  end
  
  -- Add the vectors element-wise
  local sum = {}
  for i = 1, size do
    local s = 0
    for j, v in ipairs(vectors) do
      s = s + v[i]
    end
    table.insert(sum, s)
  end
  
  -- Save the sum vector to file
  local sum_name = table.concat(vector_names, "_") .. "_sum"
  local sum_file = io.open(sum_name .. ".txt", "w")
  sum_file:write(table.concat(sum, ","))
  sum_file:close()
  
  return sum
end
