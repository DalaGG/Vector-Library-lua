
--[[

dimreduct_vectors
The dimreduct_vectors function reduces the dimensionality of a vector by projecting it onto a lower dimensional space. It takes two arguments: vector and n, where vector is the vector to be reduced and n is the desired dimensionality of the resulting vector.

Syntax:

result = dimreduct_vectors(vector, n)


Parameters
vector (table): The vector to be reduced.
n (number): The desired dimensionality of the resulting vector.
Returns
result (table): The resulting vector after dimensionality reduction.
Example:

-- Load the vector library
local Vector = require("Vector")

-- Create a vector
local v = Vector.create_vector("1,2,3")

-- Reduce the dimensionality of the vector to 2
local result = Vector.dimreduct_vectors(v, 2)

-- Print the resulting vector
print(table.concat(result, ","))

This will output: 0.26726124191242,0.53452248382485.

In this example, the dimreduct_vectors function is used to reduce the dimensionality of a vector from 3 to 2. The resulting vector is then printed using table.concat.


]]


local function dimreduct_vectors(vectors, num_dimensions)
  -- Get the size of each vector
  local sizes = {}
  for i, v in ipairs(vectors) do
    sizes[i] = Vector.get_size(v)
  end

  -- Find the smallest size
  local min_size = math.min(table.unpack(sizes))

  -- Create the matrix
  local matrix = torch.Tensor(min_size, #vectors)

  -- Fill the matrix with vector values
  for i, v in ipairs(vectors) do
    for j = 1, min_size do
      matrix[j][i] = v[j]
    end
  end

  -- Apply SVD to the matrix to reduce its dimensionality
  local u, s, v = torch.svd(matrix)

  -- Take the first 'num_dimensions' columns of u as the reduced matrix
  local reduced_matrix = u[{{}, {1, num_dimensions}}]

  -- Convert the reduced matrix back to a set of vectors
  local reduced_vectors = {}
  for i = 1, #vectors do
    reduced_vectors[i] = {}
    for j = 1, num_dimensions do
      reduced_vectors[i][j] = reduced_matrix[j][i]
    end
  end

  return reduced_vectors
end
