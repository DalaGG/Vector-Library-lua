
--[[
example documentation for the backpropagate_vectors function:

backpropagate_vectors(output_error, weights, inputs, activation_deriv)

Backpropagate the error through a neural network and return the error gradient.

Parameters:
- output_error (table): The error in the output layer.
- weights (table): A table of weight matrices for each layer.
- inputs (table): A table of input vectors for each layer.
- activation_deriv (function): A function that computes the derivative of the activation function.

Returns:
- A table representing the error gradient.

]]


local Vector = require("Vector")

local function Vector.backpropagate(output_error, weights, inputs, activation_deriv)
    -- output_error: the error in the output layer
    -- weights: a table of weight matrices for each layer
    -- inputs: a table of input vectors for each layer
    -- activation_deriv: a function that computes the derivative of the activation function
    
    -- initialize the error gradient with the output error
    local error_gradient = Vector.create_vector(output_error)
    
    -- loop over the layers in reverse order
    for i = #weights, 1, -1 do
        -- compute the delta for this layer
        local delta = Vector.hadamard_product(error_gradient, Vector.apply_function(inputs[i], activation_deriv))
        
        -- update the error gradient for the next layer
        error_gradient = Vector.create_vector({})
        for j = 1, #weights[i] do
            local weight_column = Vector.get_column(weights[i], j)
            local delta_sum = Vector.dot_product(delta, weight_column)
            error_gradient[j] = delta_sum
        end
    end
    
    -- return the error gradient
    return error_gradient
end

return backpropagate
