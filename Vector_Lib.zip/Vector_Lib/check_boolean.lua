
--[[
Vector.check_boolean(variable, str)
This function takes a boolean variable variable and a string str as input. It checks if variable is true, and if so, 
it searches str for the substring "vector=". If "vector=" is found, it extracts the vector data and returns it. 
If "vector=" is not found, it throws an error. If variable is false, it throws an error.
]]

function Vector.check_boolean(variable, str)
    if variable then
        local start_index, end_index = string.find(str, "vector=")
        if start_index == nil then
            error("Vector not found in string.")
        end
        local vec_str = string.sub(str, end_index+1)
        local vec = load("return " .. vec_str)()
        return vec
    else
        error("Boolean variable is false.")
    end
end
