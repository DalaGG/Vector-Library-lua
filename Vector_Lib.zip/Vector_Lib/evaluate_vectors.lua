


--[[

-- Evaluate the performance of a neural network on a given dataset and return the loss and accuracy metrics.

-- Parameters:
-- - dataset (table): The dataset to evaluate, represented as a table of input-output pairs.
-- - weights (table): A table of weight matrices for each layer of the neural network.
-- - biases (table): A table of bias vectors for each layer of the neural network.
-- - activation_func (function): The activation function used in the neural network.
-- - loss_func (function): The loss function used to compute the network's loss.
-- - threshold (number): A threshold value to use when computing accuracy.
--
-- Returns:
-- - A table containing the following metrics:
--   - "loss": The average loss of the network on the given dataset.
--   - "accuracy": The percentage of correct predictions on the given dataset.
--
-- Example usage:
-- local dataset = { {input1, output1}, {input2, output2}, ... }
-- local weights = { weight_matrix1, weight_matrix2, ... }
-- local biases = { bias_vector1, bias_vector2, ... }
-- local activation_func = some_activation_function
-- local loss_func = some_loss_function
-- local threshold = 0.5
-- local metrics = evaluate_vectors(dataset, weights, biases, activation_func, loss_func, threshold)
-- print("Average loss: " .. metrics.loss)
-- print("Accuracy: " .. metrics.accuracy .. "%")

function evaluate_vectors(dataset, weights, biases, activation_func, loss_func, threshold)
   -- implementation goes here
end

]]




local Vector = require("Vector")

local function evaluate_vectors(net, dataset)
    -- net: a table representing a neural network
    -- dataset: a table of input-output pairs
    
    local num_correct = 0
    local num_total = #dataset
    
    for i = 1, num_total do
        local input = dataset[i].input
        local target_output = dataset[i].output
        
        local output = Vector.forwardprop_vectors(input, net)
        
        local predicted_index = 1
        local predicted_value = output[1]
        for j = 2, #output do
            if output[j] > predicted_value then
                predicted_index = j
                predicted_value = output[j]
            end
        end
        
        local target_index = 1
        local target_value = target_output[1]
        for j = 2, #target_output do
            if target_output[j] > target_value then
                target_index = j
                target_value = target_output[j]
            end
        end
        
        if predicted_index == target_index then
            num_correct = num_correct + 1
        end
    end
    
    local accuracy = num_correct / num_total
    
    return accuracy
end

return evaluate_vectors
