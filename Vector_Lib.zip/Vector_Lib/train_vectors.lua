--[[
example documentation for the train_vectors function:

train_vectors(inputs, outputs, hidden_sizes, activation_func, activation_deriv, learning_rate, num_epochs)

Train a neural network to map inputs to outputs.

Parameters:
- inputs (table): A table of input vectors.
- outputs (table): A table of output vectors.



- hidden_sizes (table): A table of integers specifying the number of neurons in each hidden layer.
- activation_func (function): A function that computes the activation of a neuron.
- activation_deriv (function): A function that computes the derivative of the activation function.
- learning_rate (number): The learning rate to use during training.
- num_epochs (number): The number of epochs to train for.

Returns:
- A table representing the trained neural network.
]]


local Vector = require("Vector")
local forwardprop_vectors = require("forwardprop_vectors")
local backpropagate_vectors = require("backpropagate_vectors")


local function Vector.train_vectors(inputs, outputs, hidden_sizes, activation_func, activation_deriv, learning_rate, num_epochs)
    -- initialize the weights and biases for the neural network
    local layer_sizes = Vector.create_vector({#inputs[1], table.unpack(hidden_sizes), #outputs[1]})
    local weights = {}
    local biases = {}
    for i = 1, #layer_sizes - 1 do
        weights[i] = Vector.create_random_matrix(layer_sizes[i], layer_sizes[i+1], -1, 1)
        biases[i] = Vector.create_random_vector(layer_sizes[i+1], -1, 1)
    end
    
    -- train the neural network for the specified number of epochs
    for epoch = 1, num_epochs do
        -- loop over the training examples
        for i = 1, #inputs do
            -- forward propagation
            local output = forwardprop_vectors(inputs[i], weights, biases, activation_func)
            
            -- compute the error in the output layer
            local output_error = Vector.sub_vectors(output[#output], outputs[i])
            
            -- backward propagation
            local error_gradient = backpropagate_vectors(output_error, weights, output, activation_deriv)
            
            -- update the weights and biases
            for j = 1, #weights do
                weights[j] = Vector.sub_matrices(weights[j], Vector.scaling_matrix(Vector.outer_product(output[j], error_gradient), learning_rate))
                biases[j] = Vector.sub_vectors(biases[j], Vector.scaling_vector(error_gradient, learning_rate))
            end
        end
    end
    
    -- return the trained neural network
    return {
        weights = weights,
        biases = biases,
        activation_func = activation_func
    }
end

return train_vectors
