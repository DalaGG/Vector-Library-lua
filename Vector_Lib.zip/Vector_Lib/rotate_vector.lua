

--[[
-- Import Vector library and rotate_vector function
local Vector = require("Vector")
local rotate_vector = require("rotate_vector")

-- Load vector data from Vector_Var.txt file
local vectors = Vector.get_vectors()

-- Select the vector to rotate
local target_vector = vectors[1] -- Assume first vector is selected

-- Define rotation angle in degrees
local angle = 45

-- Call the rotate_vector function to rotate the vector
local rotated_vector = rotate_vector(target_vector, angle)

-- Print the rotated vector
print("Rotated vector:", rotated_vector)


The rotate_vector function takes two arguments: target_vector and angle.

target_vector is a Lua table that represents the vector to rotate. The table should have x and y fields that represent the vector's coordinates. For example: {x = 3, y = 4} represents the vector (3, 4).

angle is the rotation angle in degrees. A positive angle rotates the vector clockwise, while a negative angle rotates the vector counterclockwise.

The rotate_vector function returns a new Lua table that represents the rotated vector. The table has x and y fields that represent the vector's new coordinates.

Note that the rotate_vector function assumes that the vector is anchored at the origin (0, 0). If the vector is anchored at a different point, you can translate it to the origin, rotate it, and then translate it back to its original position.

]]


-- Load required Vector library functions
local Vector = require("int")

--- Rotate a vector by a given angle around the origin.
-- @param vector The vector to rotate.
-- @param angle The angle to rotate the vector by (in radians).
-- @return The rotated vector.
function Vector.rotate_vector(vector, angle)
  -- Ensure the input vector is valid
  if not Vector.check_boolean(vector) then
    error("Error: Invalid vector input.")
  end

  -- Get the size of the input vector
  local size = Vector.get_size(vector)

  -- Ensure the input vector has two or three dimensions
  if size ~= 2 and size ~= 3 then
    error("Error: Input vector must have two or three dimensions.")
  end

  -- Calculate the rotation matrix based on the input angle
  local cos_angle = math.cos(angle)
  local sin_angle = math.sin(angle)

  local rotation_matrix
  if size == 2 then
    rotation_matrix = {
      {cos_angle, -sin_angle},
      {sin_angle, cos_angle}
    }
  elseif size == 3 then
    rotation_matrix = {
      {1, 0, 0},
      {0, cos_angle, -sin_angle},
      {0, sin_angle, cos_angle}
    }
  end

  -- Multiply the input vector with the rotation matrix to get the rotated vector
  local rotated_vector = {}
  for i = 1, size do
    rotated_vector[i] = 0
    for j = 1, size do
      rotated_vector[i] = rotated_vector[i] + rotation_matrix[i][j] * vector[j]
    end
  end

  return rotated_vector
end

return Vector
